#include "multiset.h"
#include <iostream>

/* Put your implementation here */
template<class T> MultiSet<T>::MultiSet(int size)
{

}


template<class T> void MultiSet<T>::insertion(T item)
{

}

template<class T> void MultiSet<T>::deletion(T item)
{

}

template<class T> T MultiSet<T>::retrieval(T item)
{

}


//*****************************************************


template<class T> MultiSet_Chaining<T>::MultiSet_Chaining(int size)
{
    
}


template<class T> void MultiSet_Chaining<T>::insertion(T item)
{

}

template<class T> void MultiSet_Chaining<T>::deletion(T item)
{

}

template<class T> T MultiSet_Chaining<T>::retrieval(T item)
{

}
